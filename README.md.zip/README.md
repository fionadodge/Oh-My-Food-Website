# fiona.dodge_3_11292022_A

Hi,
I will be happy to talk through this work in my presentation. 

Link to my Vercel static site:
https://fiona-dodge-3-11292022-a.vercel.app

